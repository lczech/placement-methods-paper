#!/usr/bin/Rscript

proj <- read.csv( file="interesting_edges_2.txt", sep="\t", head=FALSE )

# head(proj)

# palette( heat.colors(6) )
# palette( topo.colors(6) )
# palette( terrain.colors(6) )

rbPal <- colorRampPalette(c('blue','red'))
colpal <- rbPal(6)[as.numeric(cut( proj$V3, breaks = 6))]

# cuts<-levels(cut( proj$V4,breaks = 6 ))
# cuts<-gsub(","," - ",cuts)
# cuts<-gsub("\\(","[",cuts)
cuts <- c( "0", "2", "4", "6", "8", "10" )
symbol <- 1

svg( "corr_test_362_nug.svg" )
plot( proj$V1, proj$V3, pch=symbol, col=colpal )

svg( "corr_test_1015_nug.svg" )
plot( proj$V2, proj$V3, pch=symbol, col=colpal )

svg( "corr_test_362_1015.svg" )
plot( proj$V1, proj$V2, pch=symbol, col=colpal )

svg( "corr_test_nug_362.svg" )
plot( proj$V3, proj$V1, pch=symbol, col=colpal )

svg( "corr_test_nug_1015.svg" )
plot( proj$V3, proj$V2, pch=symbol, col=colpal )

svg( "corr_test_1015_362.svg" )
plot( proj$V2, proj$V1, pch=symbol, col=colpal )

# edge_362	edge_1015	nugent
