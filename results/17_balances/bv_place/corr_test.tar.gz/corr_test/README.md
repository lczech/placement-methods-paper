This was a test to find out why the correlation between balances and nugent score is so damn high for all the branches with no placement mass.
In the end, it turned out that this is due to properties of the geometric mean: it is not sensitive to single large values.
as however the dataset has healthy women with a single branch of lactobac having all of the placement mass, the respective geom mean in the denominator of the balance calculation is low, compared to the sick women, which have a lot more different clades with elevated placement mass, so that the geom mean rises.
hence: sick women -> higher denominator compared to healthy ones -> lower balance -> anti correlation with nugent score.

the plots in this dir show numerator vs denominator of the balances for one of the edges (id 1015), and their log (mimicking the balance), colored by nugent score.
interesting features appear: the line in `corr_test_num_den.svg` stems from the pseudo counts: all edges get a constant pseudo count added to avoid zero values (as they do not work in geom mean). then, samples are normalized to unit mass. hence, samples with more sequences in them normalize the pseudo counts of edges with no mass differently (smaller) than samples with fewer sequences in them.
this affects all branches, so both the num and denom are affected the same - hence the linear relationship.
this does not matter for the balance, as it cancels out when dividing the numbers.
all values in the plot are above the x=y line, which simply means that the denom is higher than the num, because this is a clade with no placement mass, so the num is small.
the separation of red and blue is what's really intersting: all red ones have an even higher denom than the blue ones. this is the property that we discussed before: geom mean for the healthy ones does not elevate that much, because all the mass is concentrated in a single branch, and geom mean is insentitive to that.

then, we wanted to figure out why this does not affect the glm prediction. this is waht the subdirs are for: the ie (interestind ege) tests show plots for the same edge (index 1015) as well as the winning edge of the first factor, for comparing why they are different. basically, it's because in the 1015 edge, although balances correlate with nugent score as described above, all balances are still pretty small and almost constant. hence, an intercept models them quite well. for the winning edge (index 362), this is different: it of course also has a high correl with nugent score, but also the balances differen significantly for samples that have a lot of placements in the clade behind the winning edge. hence, the null model (intercept) does not model them well, given a large error. a linear predictor hence scores higher here.

this tells us is that glms are good objective functions, while correlation are skewed by small number issues...

the subdirectories: 

 * `factor_corr`: tested what happens if we use correlation as objective function in phylo factorization. as expected, a lot of nonsense edges!
 * `ie tests`: ie stands for interesting edges. just the two edges above that we picked as examples to see what is going on
