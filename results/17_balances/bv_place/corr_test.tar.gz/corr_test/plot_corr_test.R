#!/usr/bin/Rscript

proj <- read.csv( file="corr_test.txt", sep="\t", head=FALSE )

# head(proj)

# palette( heat.colors(6) )
# palette( topo.colors(6) )
# palette( terrain.colors(6) )

rbPal <- colorRampPalette(c('blue','red'))
colpal <- rbPal(6)[as.numeric(cut( proj$V4, breaks = 6))]

# cuts<-levels(cut( proj$V4,breaks = 6 ))
# cuts<-gsub(","," - ",cuts)
# cuts<-gsub("\\(","[",cuts)
cuts <- c( "0", "2", "4", "6", "8", "10" )

svg( "corr_test_num_den.svg" )
plot( proj$V1, proj$V2, pch=19, col=colpal )

svg( "corr_test_num_nug.svg" )
plot( proj$V1, proj$V4, pch=19, col=colpal )

svg( "corr_test_den_nug.svg" )
plot( proj$V2, proj$V4, pch=19, col=colpal )

svg( "corr_test_log_nug.svg" )
plot( proj$V3, proj$V4, pch=19, col=colpal )

