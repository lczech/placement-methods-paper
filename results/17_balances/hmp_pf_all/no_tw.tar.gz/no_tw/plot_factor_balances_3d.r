#!/usr/bin/Rscript

library(RColorBrewer)
library(scales)
library("plot3D")
#library(plotly)

proj <- read.csv( file="factor_balances_all.csv", sep=",", head=FALSE )

x <- proj$V2
y <- proj$V3
z <- proj$V4

meta_full <- proj$V12

# Summarize certain body sites, in order to get a clear plot.
# The order of entries in this list is important, as it is the order of the category labels 0-19.
# We hand select the order of colors, so that nearby clusters get different colors,
# in order to be distinguishable from each other.
# Also, we select them to be somehow relatable to the body site.
set = brewer.pal(9,"Set1")
col_pal_19 = c(
    set[7],	#  1 Stool
    set[5],	#  2 Mouth (back)
    set[5],	#  3 Mouth (back)
    set[5],	#  4 Mouth (back)
    set[1],	#  5 Saliva
    set[4],	#  6 Mouth (front)
    set[4],	#  7 Mouth (front)
    set[4],	#  8 Mouth (front)
    set[3],	#  9 Plaque
    set[3],	# 10 Plaque
    set[2],	# 11 Skin
    set[2],	# 12 Skin
    set[9],	# 13 Airways
    set[2],	# 14 Skin
    set[2],	# 15 Skin
    set[8],	# 16 Vagina
    set[8],	# 17 Vagina
    set[8],	# 18 Vagina
    0 # set[6]	# 19 n/a
)

# Set1 Colors
# 1 red
# 2 blue
# 3 green
# 4 purple
# 5 orange
# 6 yellow
# 7 brown
# 8 pink
# 9 gray

# Make a legend. The order here is arbitrary (we order head to toe, kind of...),
# but needs to be maintainted between the two lists.
leg_txt_cat = c(
    "Mouth (back)",
    "Mouth (front)",
    "Saliva",
    "Plaque",
    "Airways",
    "Skin",
    "Stool",
    "Vagina"
    # "n/a"
)
leg_col_cat = c(
    col_pal_19[2],
    col_pal_19[6],
    col_pal_19[5],
    col_pal_19[9],
    col_pal_19[13],
    col_pal_19[11],
    col_pal_19[1],
    col_pal_19[16]
    # col_pal_19[19]
)

#' Get colors for the different levels of 
#' a factor variable
#' 
#' @param groups a factor variable containing the groups
#'  of observations
#' @param colors a vector containing the names of 
#   the default colors to be used
get_colors <- function(groups, group.col = palette()){
  groups <- as.factor(groups)
  ngrps <- length(levels(groups))
  if(ngrps > length(group.col)) 
    group.col <- rep(group.col, ngrps)
  color <- group.col[as.numeric(groups)]
  names(color) <- as.vector(groups)
  return(color)
}

good_cols <- get_colors(meta_full, leg_col_cat)

# Color assignments
col_ass_19 <- col_pal_19[as.numeric(cut( meta_full, breaks = 19))]
ass_19 <- as.integer(cut( meta_full, breaks = 19))

# http://www.sthda.com/english/wiki/r-plot-pch-symbols-the-different-point-shapes-available-in-r
symbol <- 20
sym_size <- 0.4
leg_sym <- 19
leg_size <- 1

svg( "factor_balances_full_3d.svg" )
scatter3D( 
	-x, y, z, pch=symbol, cex=sym_size, colvar=ass_19, col=col_pal_19,  
	xlab = "Factor 1", ylab ="Factor 2", zlab = "Factor 3",
	phi = 18, theta = 40 # rotation
#	bty = "g" 	# background style, default "b"
)

#plot_ly(proj, x = ~V2, y = ~V3, z = ~V4, color = ~col_ass_19, colors = ~col_pal_19)
#legend("topright", legend=leg_txt_cat, col=leg_col_cat, pch=leg_sym, cex=leg_size )

