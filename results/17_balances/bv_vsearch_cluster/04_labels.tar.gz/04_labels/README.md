Label the cluster sequences with the reference names:

1. align them to the bv ref tree
2. place them on the bv ref tree
3. run gappa assign

