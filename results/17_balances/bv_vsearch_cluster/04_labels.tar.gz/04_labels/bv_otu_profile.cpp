/*
    Genesis - A toolkit for working with phylogenetic data.
    Copyright (C) 2014-2018 Lucas Czech and HITS gGmbH

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Contact:
    Lucas Czech <lucas.czech@h-its.org>
    Exelixis Lab, Heidelberg Institute for Theoretical Studies
    Schloss-Wolfsbrunnenweg 35, D-69118 Heidelberg, Germany
*/

#include "genesis/genesis.hpp"

#include <algorithm>
#include <cassert>
#include <fstream>
#include <limits>
#include <random>
#include <string>
#include <unordered_map>

using namespace genesis;
using namespace genesis::sequence;
using namespace genesis::utils;

int main( int, char** )
{
    // -------------------------------------------------------------------------
    //     Startup and command line args
    // -------------------------------------------------------------------------

    // Activate logging.
    utils::Logging::log_to_stdout();
    utils::Logging::details.time = true;
    LOG_BOLD << utils::Options::get().info();
    LOG_BOLD;

    LOG_INFO << "Started";

    // In out dirs.
    std::string const base_dir = "path/to/17_balances/";
    std::string const profile_file = base_dir + "bv_vsearch_cluster/04_labels/per_pquery_assign";
    std::string const out_file = base_dir + "bv_vsearch_cluster/04_labels/otu_assignments.txt";

    auto csv_reader = CsvReader();
    csv_reader.separator_chars( "\t" );
    auto const assign = csv_reader.read( from_file( profile_file ));

    std::ofstream tax_of;
    file_output_stream( out_file, tax_of );

    std::string cur_otu;
    std::string cur_tax;
    for( auto const& line : assign ) {
        if( line.size() == 1 ) {
            if( ! cur_otu.empty() ) {
                auto p = cur_otu.find_first_of(";");
                cur_otu = cur_otu.substr( 0, p );
                tax_of << cur_otu << "\t" << cur_tax << "\n";
            }
            cur_otu = line[0];
        } else {
            assert( line.size() == 5 );
            cur_tax = line[4];
        }
    }

    auto p = cur_otu.find_first_of(";");
    cur_otu = cur_otu.substr( 0, p );
    tax_of << cur_otu << "\t" << cur_tax << "\n";

    LOG_INFO << "Finished";
    return 0;
}
