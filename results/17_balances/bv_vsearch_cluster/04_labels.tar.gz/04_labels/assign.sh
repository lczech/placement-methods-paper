#!/bin/bash

gappa=path/to/github/gappa/bin/gappa

jplace=path/to/17_balances/bv_vsearch_cluster/04_labels/epa_result.jplace
tax=path/to/17_balances/bv_swarm/03_labels/taxon_file.txt
outgr=path/to/17_balances/bv_swarm/03_labels/assign/outgroup.txt

$gappa analyze assign --jplace-path $jplace --taxon-file $tax --root-outgroup $outgr
