cluster the bv sample sequences into otus, and select the most abundand otus:

 1. `derep_samples.sh`: prepare a file with all seqs of all 220 samples, including a sample identifier
 2. `vsearch_cluster.sh`: run vserach on this file, to cluster it into otus
 3. `derep_samples_otutab.ods`: select the otus that appear in 10% or more of the samples
 4. `filter_otus.sh`: get the consensus sequences of these otus
 
the result file is `derep_samples_otus_22_clean.fasta`, which is then used for tree inference.
