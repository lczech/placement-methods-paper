#!/bin/bash

BASEDIR="path/to"

VSEARCH=`which vsearch`

INPUT_FASTA=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep_samples.fasta
THREADS=4

echo "`date` starting vsearch: clustering"
echo

rm -fv derep_samples_*.fasta

${VSEARCH} \
    --cluster_size ${INPUT_FASTA} \
    --centroids ${INPUT_FASTA/.fasta/_centroids.fasta} \
    --consout ${INPUT_FASTA/.fasta/_consensus.fasta} \
    --clusterout_id \
    --msaout ${INPUT_FASTA/.fasta/_msa.fasta} \
    --otutabout ${INPUT_FASTA/.fasta/_otutab.csv} \
    --sizein --sizeout --fasta_width 0 \
    --threads ${THREADS} --id 0.98 --clusterout_sort


#echo
#echo "`date` starting vsearch: sort representatives"
# Sort representatives
#"${VSEARCH}" --fasta_width 0 \
#             --sortbysize ${REPRESENTATIVES} \
#             --output ${REPRESENTATIVES}.sorted

echo
echo "`date` finished"
