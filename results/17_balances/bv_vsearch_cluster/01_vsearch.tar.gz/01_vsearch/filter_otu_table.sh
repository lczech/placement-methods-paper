#!/bin/bash

BASEDIR="path/to"

INPUT_TABLE=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep_samples_otutab.csv
OTU_LIST=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/otu_list_22.txt
OUT_TABLE=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep_samples_otutab_22.csv

rm -rf ${OUT_TABLE}
head -n 1 ${INPUT_TABLE} > ${OUT_TABLE}

for otu in `cat ${OTU_LIST}` ; do
    echo $otu
    
    # >centroid=2135da08a8e7a66166d847f80a6b9705446b2ea8;sample=p1z1r34;;seqs=2517;clusterid=1;size=34050
    cat ${INPUT_TABLE} | grep ${otu} >> ${OUT_TABLE}
done

