#!/bin/bash

BASEDIR="path/to"

INPUT_FASTA=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep_samples_consensus.fasta
OTU_LIST=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/otu_list_22.txt
OUT_FASTA=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep_samples_otus_22.fasta

rm -rf ${OUT_FASTA}

for otu in `cat ${OTU_LIST}` ; do
    echo $otu
    
    # >centroid=2135da08a8e7a66166d847f80a6b9705446b2ea8;sample=p1z1r34;;seqs=2517;clusterid=1;size=34050
    cat ${INPUT_FASTA} | grep -A 1 ${otu} >> ${OUT_FASTA}
done

cat ${OUT_FASTA} | sed "s/>centroid=\([^;]*\);.*/>\1/g" > ${OUT_FASTA/.fasta/_clean.fasta}

