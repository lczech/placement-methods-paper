#!/bin/bash

BASEDIR="path/to"

VSEARCH=`which vsearch`

INPUT_DIR=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep/ 
#*.fasta
OUT_FASTA=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep_samples.fasta

rm -rf ${OUT_FASTA}

cd ${INPUT_DIR}
for file in `ls *.fasta` ; do
    echo $file
    
    cat $file | sed "s/\(>.*\)/\1;sample=${file/.fasta/};/g" >> ${OUT_FASTA}
done
cd -
	
