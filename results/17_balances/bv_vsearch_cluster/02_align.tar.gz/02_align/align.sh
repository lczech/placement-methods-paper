#!/bin/bash

BASEDIR="path/to"

MAFFT=`which mafft`

SEQS=${BASEDIR}/17_balances/bv_vsearch_cluster/01_vsearch/derep_samples_otus_22_clean.fasta
THREADS=2

echo "`date` starting align"
echo

#mafft-linsi ${SEQS} > derep_all_consensus.align_clean.fasta
mafft --auto ${SEQS} > derep_samples_otus_22_align.fasta

#cat derep_all_consensus.align_auto.fasta | sed "s/centroid=\([^;]*\);.*/\1/g" > derep_all_consensus.align_auto_clean.fasta

echo
echo "`date` finished"
