#!/bin/bash

rm -f OTU_tree.newick
cp ../03_treesearch/derep_samples_otus_22_align.fasta.raxml.bestTree OTU_tree.newick

labels="../04_labels/otu_assignments_species_only.txt"

while IFS='' read -r line || [[ -n "$line" ]]; do

	o=`echo -e $line | cut -f 1 -d ' '`
	s=`echo -e $line | cut -f 1 -d ' ' --complement | sed "s/ /_/g"`
	
	sed -i "s/${o}/${s}/g" OTU_tree.newick

done < "${labels}"
