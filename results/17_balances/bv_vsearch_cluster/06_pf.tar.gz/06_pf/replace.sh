#!/bin/bash

rm -f phylofactor_replaced.log
cp phylofactor.log phylofactor_replaced.log

labels="../04_labels/otu_assignments_species_only.txt"

while IFS='' read -r line || [[ -n "$line" ]]; do

	o=`echo -e $line | cut -f 1 -d ' '`
	s=`echo -e $line | cut -f 1 -d ' ' --complement | sed "s/ /_/g"`
	
	sed -i "s/${o}/${s}/g" phylofactor_replaced.log

done < "${labels}"
