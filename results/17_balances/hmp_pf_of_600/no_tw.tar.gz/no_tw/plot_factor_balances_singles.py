#!/usr/bin/python

# libraries
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
# from matplotlib import pyplot
import matplotlib.mlab as mlab
import numpy as np
import pandas as pd
import seaborn as sns
import os
#from bokeh.palettes import Paired
from bokeh.palettes import Set1

# -----------------------------------------------------------------------------
#     Read Data
# -----------------------------------------------------------------------------

print( "read data" )
data = pd.read_csv( "factor_balances_all.csv", header=None, sep="," )
# print "   data.shape", data.shape
# print( "   data.columns", data.columns )

# -----------------------------------------------------------------------------
#     Color Settings
# -----------------------------------------------------------------------------

# Color settings
print( "color shit" )
#ps=Paired[12] #sns.color_palette("Set1")
ps=Set1[9]
# site_label=[ 7, 5, 5, 5, 1, 4, 4, 4, 3, 3, 2, 2, 9, 2, 2, 8, 8, 8 ]
# site_label=[ 0, 1, 1, 1, 2, 3, 3, 3, 4, 4, 5, 5, 6, 5, 5, 7, 7, 7 ]
# pal = [ ps[6], ps[4], ps[0], ps[3], ps[2], ps[1], ps[8], ps[7] ]
site_label=[
	'Mouth', 'Stool'
]
pal = {
	'Stool':  ps[6],
	'Mouth':  ps[2]
}
order = [ 'Mouth', 'Stool' ]

# -----------------------------------------------------------------------------
#     Transmogrify
# -----------------------------------------------------------------------------

# Transform to what the plot tool needs
partial=1
print( "transmogrify (" + str(partial) + ")" )
df = pd.DataFrame( index=range(0, 10 * len(data) // partial), columns=['Factor', 'Value', 'Site'])
counter=0
for i in range(1, 11):
	fac_col=data[data.columns[i]]
	sit_col=data[data.columns[11]]

	fc_min=abs(fac_col.min())
	fc_max=abs(fac_col.max())
	div=max(fc_min,fc_max)

	for j in range(0, len(fac_col), partial):
		df.at[counter, 'Factor'] = "PF" + str(i)
		# df.at[counter, 'Value']  = fac_col[j]
		df.at[counter, 'Value']  = fac_col[j] / div
		# df.at[counter, 'Value']  = (fac_col[j] + fc_min) / ( fc_min + fc_max )
		df.at[counter, 'Site']   = site_label[sit_col[j]]
		counter += 1

	# df = df.append(fac_col).reset_index(drop=True)
	# df = df.append(sit_col).reset_index(drop=True)

# df = df.sort_values(by=['Factor', 'Site'])
# print "   df.shape", df.shape
# print "   df.columns", df.columns

# -----------------------------------------------------------------------------
#     Summary Plot
# -----------------------------------------------------------------------------

print( "plot all" )
plt.figure( 0 )
sns.set_style("darkgrid")
sns.set(style="ticks", color_codes=True)
sns.set(style="whitegrid", palette="muted")

# sns.swarmplot( x="Factor", y="Value", hue="Site", data=df )

g = sns.swarmplot(
	x="Factor", y="Value", hue="Site", data=df, palette=pal, hue_order=order, alpha = 1.0, s = 0.9
)

#g = sns.catplot(
# 	x="Factor", y="Value", hue="Site", data=df, palette=pal, hue_order=order, legend_out=True,
# 	alpha = 0.9,
# 	s = 3.0,
# 	height=5, aspect=2, jitter=0.25
#)

# g.set(yticklabels=[])
# g.legend_.remove()

# plt.savefig( "factor_balances_full_singles.png", format='png')
plt.savefig( "factor_balances_full_singles.svg", format='svg')

# -----------------------------------------------------------------------------
#     Single Factor Plots
# -----------------------------------------------------------------------------

for i in range(1,11):
	print( "plot  " + str(i) )
	plt.figure( i )

	vio_col=i
	df2 = pd.DataFrame( index=range(0, len(data) // partial), columns=['Factor', 'Balance', 'Site'])
	fac_col=data[data.columns[vio_col]]
	sit_col=data[data.columns[11]]
	counter=0
	for j in range(0, len(fac_col), partial):
		df2.at[counter, 'Factor'] = "PF" + str(vio_col)
		df2.at[counter, 'Balance']  = fac_col[j]
		df2.at[counter, 'Site']   = site_label[sit_col[j]]
		counter += 1

	# print(df2)

	sns.violinplot(
		x=df2["Site"], y=df2["Balance"].astype("float"), palette=pal, hue_order=order,
		order=order,
		# cut=0,
		scale="width",
		# inner=None,
		# inner="stick",
		bw = 0.3,
		linewidth=0.5
	)
	# sns.violinplot( x="Site", y="Value", data=df2 )

	# sns.violinplot( x="Site", y="Value", data=df2, palette=pal, hue_order=order)
	# hue="Site",

	# plt.savefig( "factor_balances_full_singles_" + str(i) + ".png", format='png')
	plt.savefig( "factor_balances_full_singles_" + str(i) + ".svg", format='svg')
