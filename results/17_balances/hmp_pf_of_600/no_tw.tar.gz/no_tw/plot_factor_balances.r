#!/usr/bin/Rscript

library(RColorBrewer)
library(scales)

proj <- read.csv( file="factor_balances.csv", sep="\t", head=FALSE )

X <- proj$V2
Y <- proj$V3

meta_full <- proj$V12

# Summarize certain body sites, in order to get a clear plot.
# The order of entries in this list is important, as it is the order of the category labels 0-19.
# We hand select the order of colors, so that nearby clusters get different colors,
# in order to be distinguishable from each other.
# Also, we select them to be somehow relatable to the body site.

#set = brewer.pal(12,"Paired")
set = brewer.pal(9,"Set1")
col_pal_2 = c(
    set[3],	#  0 Mouth
    set[7]	#  1 Stool
)

# Make a legend. The order here is arbitrary (we order head to toe, kind of...),
# but needs to be maintainted between the two lists.
leg_txt_cat = c(
    "Mouth",
    "Stool"
)
leg_col_cat = c(
    col_pal_2[1],
    col_pal_2[2]
)

# Color assignments
col_ass_2 <- col_pal_2[as.numeric(cut( meta_full, breaks = 2))]

# http://www.sthda.com/english/wiki/r-plot-pch-symbols-the-different-point-shapes-available-in-r
symbol <- 20
sym_size <- 0.4
leg_sym <- 19
leg_size <- 1

svg( "factor_balances_full.svg" )
plot( X, Y, pch=symbol, cex=sym_size, col=col_ass_2 )
legend("topright", legend=leg_txt_cat, col=leg_col_cat, pch=leg_sym, cex=leg_size )


