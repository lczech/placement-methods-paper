#!/usr/bin/env python

# Copyright (C)2019 Pierre Barbera

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Contact:
# Pierre Barbera <Pierre.Barbera@h-its.org>
# Exelixis Lab, Heidelberg Institute for Theoretical Studies
# Schloss-Wolfsbrunnenweg 35, D-69118 Heidelberg, Germany

import os
import sys
import json
import pandas as pd
from math import log

script_dir = os.path.dirname(os.path.realpath(__file__))

base_dir = os.path.realpath(os.path.join(script_dir, "../"))


def num_taxa(delim):
    num=0
    for taxa_list in delim.itervalues():
        for taxon in taxa_list:
            num += 1
    return num

def len_intersect(lhs, rhs):
    return len([value for value in lhs if value in rhs])

def entropy(part, N):
    ret_sum=0.0

    for p in part.itervalues():
        ret_sum += ( len(p) / N ) * log( len(p) / N )

    return -ret_sum

# a function to take two delimitations and calculate the NMI between them
def NMI(truth, delim):
    N=float(num_taxa(truth))
    I=0.0
    for t in truth.itervalues():
        for d in delim.itervalues():
            intersize = len_intersect(t, d)
            if intersize > 0:
                I += (intersize / N) * log( (intersize * N) / (len(t) * len(d)) )

    return I / max( entropy(truth, N), entropy(delim, N) )

# print NMI(qry_map, truth)

def containment( lhs, rhs ):
    total=float(len(lhs))
    hits=0
    for elem in lhs:
        if elem in rhs:
            hits += 1
    return hits / total

no_tax_df = pd.read_csv( "no_tw_factor_taxa.csv", sep="\t", header=None )
tw_tax_df = pd.read_csv( "tw_factor_taxa.csv", sep="\t", header=None )
pf_tax_df = pd.read_csv( "pf_factor_taxa.csv", sep="\t", header=None )

no_tax_dict={}
no_tax_list=[]
for index, row in no_tax_df.iterrows():
    if row[0] not in no_tax_dict:
        no_tax_dict[ row[0] ] = []
    no_tax_dict[ row[0] ].append( row[1] )
    no_tax_list.append( row[1] )

tw_tax_dict={}
tw_tax_list=[]
for index, row in tw_tax_df.iterrows():
    if row[0] not in tw_tax_dict:
        tw_tax_dict[ row[0] ] = []
    tw_tax_dict[ row[0] ].append( row[1] )
    tw_tax_list.append( row[1] )

pf_tax_dict={}
pf_tax_list=[]
for index, row in pf_tax_df.iterrows():
    if row[0] not in pf_tax_dict:
        pf_tax_dict[ row[0] ] = []
    pf_tax_dict[ row[0] ].append( row[1] )
    pf_tax_list.append( row[1] )

# print "no_tax vs. tw_tax: {}".format(NMI(no_tax_dict, tw_tax_dict))
# print "no_tax vs. pf_tax: {}".format(NMI(no_tax_dict, pf_tax_dict))
# print "tw_tax vs. pf_tax: {}".format(NMI(tw_tax_dict, pf_tax_dict))

print "no size", len(set(no_tax_list))
print "tw size", len(set(tw_tax_list))
print "pf size", len(set(pf_tax_list))

print "no vs tw", containment( no_tax_list, tw_tax_list )
print "tw vs no", containment( tw_tax_list, no_tax_list )

print "no vs pf", containment( no_tax_list, pf_tax_list )
print "pf vs no", containment( pf_tax_list, no_tax_list )

print "tw vs pf", containment( tw_tax_list, pf_tax_list )
print "pf vs tw", containment( pf_tax_list, tw_tax_list )
