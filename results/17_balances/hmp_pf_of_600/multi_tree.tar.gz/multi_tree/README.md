here, we make a tree that is colored depending on which clades were found by which phylofactor variant,
so that we can compare three of them at the same time:

 - ours, with taxon weighing
 - ours, without taxon weighing
 - original one, using their test dataset
 
for this, we ran our placement based version, and listed the clades found by the first 10 factors. 
these lists are `tw_taxa.txt` and `no_tw_taxa.txt`.

then, we did the same for the original phylofactor, using the scripts `phylofactor.R` and `phylofactor_vis.R`,
which outputs `pf_group1_N.csv`, that is lists of otu ids found in the first 10 factors,
and `pf_taxonomy.csv`, which is the original taxonomy used by this dataset in phylofactor.
the lists then needed to be translated to their taxonomy first, and then to our taxonomy, silva,
as the tree that we want to use for visualization is our PhAT unconstr bact tree,
which is based on the silva taxonomy.
for these translations, we wrote the `pf_factor_taxa.py` script, which outputs the final list of names of the tree.
we stored the output of this in `pf_result.csv`, which contains some additional information as well,
and the final list in `pf_taxa.txt`

lastly, the tree was visualized with `hmp_factors_tree.cpp`, which takes in the tree

also, we then added `stat.py` to assess mutual information and the number of taxa shared in each of the three variants.
the latter is used in the paper as a set of descriptive numbers about the three variants.

files:

 - `best_tree.newick`: the PhAT unconstr bact tree, used for our placement-factorization of the hmp data placed on that tree
 - `FTmicrobiome.rda`: original R workspace for the oral fecal dataset of the phylofactor tutorial
 - `multi_factors_tree.svg`: result file, made with `hmp_factors_tree.cpp`
 - `no_tw_factor_taxa.csv`: list of taxa, separated by they number of the factor
 - `no_tw_taxa.txt`: list of taxa found by our variant
 - `pf.RData`: temporary of the two R scripts, so that we do not need to rerun PF all the time
 - `pf_factor_taxa.py`: script to turn the R output into a nice list
 - `pf_group1_N.csv`: output of the R script
 - `pf_result.csv`: output of the python script
 - `pf_factor_taxa.csv`: list of taxa, separated by they number of the factor 
 - `pf_taxa.txt` the imporant column of the phython script output, used as input for the cpp script
 - `pf_taxonomy.csv` original taxonomy of the oral fecal dataset, written by the R srit
 - `phylofactor.R`: run PF on their oral fecal dataset, store some results
 - `phylofactor_vis.R` load the PF of the oral fecal data, and write more results
 - `tax_assign.txt` all taxa of our PhAT tree, used for lookup for finding taxa from the R script
 - `taxonomy.csv` taxonomy of the oral fecal dataset
 - `tax_slv_ssu_123.1.txt` silva taxonomy, for testing only. we needed just the taxa that were in the tree in the end
 - `tw_factor_taxa.csv`: list of taxa, separated by they number of the factor
 - `tw_taxa.txt` list of taxa found by our variant
