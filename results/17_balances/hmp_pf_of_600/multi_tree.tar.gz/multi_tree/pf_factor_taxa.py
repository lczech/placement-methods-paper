#!/usr/bin/python

# libraries
import numpy as np
import pandas as pd
import os

# -----------------------------------------------------------------------------
#     Read Data
# -----------------------------------------------------------------------------

# get the taxonomy used by the PF oral/fecal test dataset
# (we saved it from R)
pf_tax = pd.read_csv( "pf_taxonomy.csv", sep="," )

# get the silva taxonomy, for conversion
# silva_tax = pd.read_csv( "tax_slv_ssu_123.1.txt", sep="\t", header=None )
# silva_tax = silva_tax[0].tolist()

tree_tax = pd.read_csv( "tax_assign.txt", sep="\t", header=None )
tree_tax = tree_tax[0].tolist()

# -----------------------------------------------------------------------------
#     Read Factors
# -----------------------------------------------------------------------------

for i in range(1, 11):
	# Get the i-th list of taxa found by PF of the oral/fecal dataset
	fac = pd.read_csv( "pf_group1_" + str(i) + ".csv", header=None )
	fac = fac[0].tolist()

	# get the taxo paths in their taxonomy of the otus of the factor
	tax_list = pf_tax.loc[ pf_tax['OTU_ID'].isin(fac) ]
	tax_list = tax_list["taxonomy"].tolist()
	# print( tax_list )

	# attempt a translation
	taxcnt = 0
	for taxon in tax_list:

		# try the most specific element of the taxopath
		taxspl = taxon.split(" ")
		mostspecific = ""
		for elem in reversed(taxspl):
			if elem[-1:] == ";":
				elem = elem[:-1]
			if elem[1:3] == "__":
				elem = elem[3:]
			if elem == "":
				continue

			elem = elem.capitalize()
			# elem[0] = elem[0].upper()
			if mostspecific == "":
				mostspecific = elem

			# hitlist = [s for s in silva_tax if elem in s]
			# hitlist = [s for s in tree_tax if elem in s]
			hitlist = []
			for tt in tree_tax:
				ttspl = tt.split("_")
				if elem in ttspl:
					hitlist.append( tt )

			if len(hitlist) > 0:
				for hit in hitlist:
					print str(i) + "\t" + str(taxcnt) + "\t" + mostspecific + "\t" + elem + "\t" + hit
				break

		taxcnt += 1

	# 	break
	# break
