#!/usr/bin/Rscript

library(compositions)
library(ape)
library(phytools)
library(phangorn)
library(caper)
library(parallel)
library(magrittr)
library(Biostrings)

library(phylofactor)
library(phytools)

####################################################################
#    Reading
####################################################################

data("FTmicrobiome")

### This has the essentials - OTUTable, Taxonomy, tree and X - our independent variable.
### OTU tables, taxonomy and tree were constructed by Jack Darcy.
OTUTable <- FTmicrobiome$OTUTable        #OTU table
Taxonomy <- FTmicrobiome$taxonomy        #taxonomy
Tree <- FTmicrobiome$tree                #tree
X <- FTmicrobiome$X                      #independent variable - factor indicating if sample is from feces or tongue

# basedir <- "path/to/17_balances"
# OTUTable <- read.csv( file=file.path(basedir, "bv_vsearch_cluster/01_vsearch/derep_samples_otutab_22.csv"), sep="\t", head=TRUE, row.names = 1 )
#tree <- read.tree(file = file.path(basedir, "bv_vsearch_cluster/05_tree/derep_samples_otus_22_align.fasta.raxml.bestTree.rooted"))
# Tree <- read.tree(file = file.path(basedir, "bv_vsearch_cluster/03_treesearch/derep_samples_otus_22_align.fasta.raxml.bestTree"))
# meta <- read.csv( file=file.path(basedir, "bv_vsearch_cluster/06_pf/meta_simple.csv"), sep="\t", head=TRUE, row.names = 1 )
# Taxonomy <- read.csv( file=file.path(basedir, "bv_vsearch_cluster/04_labels/otu_assignments.txt"), sep="\t", head=FALSE, row.names = 1 )
# treenames <- read.csv( file=file.path(basedir, "bv_vsearch_cluster/04_labels/otu_assignments_species_only.txt"), sep="\t", head=FALSE, row.names = 1 )

#summary(OTUTable)
#summary(meta)
#summary(Taxonomy)
#summary(Tree)

####################################################################
#    Preparation
####################################################################

nfactors <- 10

# change taxomony to the format expected by phylofactor
# colnames(Taxonomy)[1] <- "taxonomy"
# Taxonomy$OTU_ID = row.names(Taxonomy)
# Taxonomy <- Taxonomy[c("OTU_ID", "taxonomy")]
#str(Taxonomy)

# sort by nugent score, and change to the format expected by phylofactor
# X <- X[order(X$nugent),]
# nugent <- as.numeric(unlist(X$nugent))
#nugent <- lapply(nugent, as.numeric)
#summary(nugent)

#summary(X$nugent)
#X$nugent

# sort otu table columns by nugent score
# OTUTable <- OTUTable[c(row.names(X))]

# change order in otu table to match tree, and
# change otu table to the format expected by phylofactor
OTUTable <- OTUTable[Tree$tip.label,]
# OTUTable <- as.matrix(OTUTable)
#summary(OTUTable)
#str(OTUTable)

OTUs <- rownames(OTUTable)               #OTU ids
n <- dim(OTUTable)[1]                    #number of taxa
p <- dim(OTUTable)[2]                    #number of samples

# print("OTUs")
# print(OTUs)
# print("Taxonomy")
# print(Taxonomy)

####################################################################
#    Dealing with Zeros
####################################################################

### Before we do the analysis, we need to deal with zeros.
## If the OTUTable is too big, we can try to remove extremely rare taxa.
numTaxa <- rep(0,p)
PercZeros <- numTaxa
for (ii in 1:length(numTaxa)){
  numTaxa[ii] <- sum(rowSums(OTUTable==0)<ii)
  PercZeros[ii] <- sum(OTUTable[which(rowSums(OTUTable==0)<ii),]==0)/(length(which(rowSums(OTUTable==0)<ii))*dim(OTUTable)[2])
}
par(mfrow=c(1,2))
plot(1:p,numTaxa,main='Number of Taxa with P or fewer zeros',xlab='P',ylab='# OTUs')
plot(1:p,PercZeros,main='% OTUTable = 0 if omitting taxa with P or fewer zeros',xlab='P',ylab='Number of Taxa')

### More research needs to be done to figure out the best way to deal with zeros
### and how this affects our inferences with Phylofactor. Since so many entries are 0, methods like
### the multiplicative replacement method of Martin-Fernandez (multRepl in package compositions)
### won't work (it can lead to negative-valued compositions), nor will the log-ratio Expectation Maximiazation (lrEM), which requires at least one
### column with no zeros. Barring any preferred method, and yet still wanting to analyze the information
### contained in the zeros, I'll omit all taxa with more than 30 zeros in our dataset, and replace 0 with 'delta'
ix <- which(rowSums(OTUTable==0)<30)
OTUTable <- OTUTable[ix,]
OTUs <- rownames(OTUTable)
Tree <- ape::drop.tip(Tree,which(!(Tree$tip.label %in% OTUs)))
n <- dim(OTUTable)[1]
#this yields an OTU table with 290 OTUs and 63% of its entries being zero.

delta=0.65
OTUTable[OTUTable==0]=delta
# This keeps 0<1, preserves the ratios of non-zero clades to one-another, and ensures large clades made up of zeros
# will have the same geometric mean as small clades made up of zeros (which is good, since the balances of taxa used in
# the ILR transformation at the heart of Phylofactor are proportional to the log-ratios of geometric means of taxa)
OTUTable <- OTUTable %>% t %>% clo %>% t   #we need to turn OTUTable into a compositional matrix with the closure operation

####################################################################
#    Pre-Analysis Visualization
####################################################################

# Now a few images to look at our data
par(mfrow=c(1,1))
phylo.heatmap(Tree,t(clr(t(OTUTable))))

####################################################################
#    Phylo Factor
####################################################################

PF <- PhyloFactor( OTUTable, Tree, X=X, nfactors=nfactors )

#names(PF)
#PF$factors

# Taxa <- pf.TaxaIDs(PF,Taxonomy,tree,nfactors=PF$nfactors,common.name=T)
# print("Taxa")
# print(Taxa)

### Let's do some ordination-visualization:
# svg("ordination.svg", width=35, height=20 )
# pf.visualize(PF)
# # phylofactor.visualize(PF,dimension=3)
# dev.off()

####################################################################
#    Heatmap
####################################################################

# sort treenames by tree tip labels, prefix them by uniq id.
# also, because of fucking stupid R issues,
# we need to remove white spaces from the names...
# treenames <- treenames[Tree$tip.label,]
# nicenames <- paste( seq.int(1, length(treenames)), treenames )
# nicenames <- gsub(" ", "_", nicenames)
# nicenames <- gsub("\\.", "", nicenames)
#summary(treenames)

# now replace all by the nice tree names
heatdata <- PF$Data
heattree <- Tree
# row.names(heatdata) <- nicenames
# heattree$tip.label <- nicenames

clr <- function(Matrix) apply(Matrix,MARGIN=2,FUN=function(x) log(x)-mean(log(x)))
par(mfrow=c(1,1))

# write data matrix to file
write.table(heatdata, file="heatdata.txt")
write.table(clr(heatdata), file="heatdata_clr.txt")

svg("heatmap.svg", width=35, height=20 )
phylo.heatmap( heattree, clr(heatdata), fsize=c(0.5, 0.5, 2.0) )
dev.off()

# save("pf.rda")
save.image(file = "pf.RData")
q()

####################################################################
#    Factored Edges
####################################################################

for (factor in 1:nfactors){

	print("======================================================")

	print(paste("Factor:", factor))
	FactorSummary <- pf.summary(PF,Taxonomy,factor=factor)

	# print the taxo paths of the groups split by this factor
	print( FactorSummary$TaxaSplit %>% lapply(.,FUN=function(x) unique(x$TaxaIDs)) )

	# factored edges
	factored.edge <- getFactoredEdges(PF$basis[,factor],Tree)
    #factored.edges <- getFactoredEdgesPAR(ncores=3,PF=PF) #Parallel; gets all factored edge

	Group1.otus <- FactorSummary$group1$IDs$otuIDs %>% as.list %>% sapply(.,toString)
	Group2.otus <- FactorSummary$group2$IDs$otuIDs %>% as.list %>% sapply(.,toString)
	Group1.edges <- extractEdges(Tree,taxa=Group1.otus,type=3)
	Group2.edges <- extractEdges(Tree,taxa=Group2.otus,type=3)

	# TidySummary <- pf.tidy(FactorSummary)

	print("Group1 tax:")
	print( Taxonomy[ FactorSummary$group1$IDs, ] )
	print("")
	print("Group2 tax:")
	print( Taxonomy[ FactorSummary$group2$IDs, ] )
	print("")
	print("")

	print("Group1.otus:")
	print( Taxonomy[Group1.otus, ])
	print("")
	print("Group2.otus:")
	print( Taxonomy[Group2.otus, ])

	edge.colors <- rep('black',Nedge(Tree))
	edge.colors[Group1.edges] <- 'green'
	edge.colors[Group2.edges] <- 'blue'
	edge.colors[factored.edge] <- 'red'

	### Let's also exaggerate the length of our factored edge:
	edge.lengths <- Tree$edge.length
	edge.lengths[factored.edge] <- 0.6

	svg(paste("tree_", factor, ".svg", sep=""), width=10, height=10)
	tr <- heattree
	tr$edge.length <- edge.lengths
	par(mfrow=c(1,1))
	plot.phylo(tr,type='phylogram',edge.color = edge.colors,show.tip.label = T,edge.width = 1,main=paste('Factor', factor), align.tip.label=T, cex=0.3)

	legend(-0.16,0.3,legend=c('Group 1','factored edge','Group 2'),fill=c('blue','red','green'))
	dev.off()

	print("")
	print("")
	# cat("\n\n")
}

####################################################################
#    ILR Ordination
####################################################################

#pf.ILRprojection(PF)
ilr.projection <- pf.ILRprojection(PF,nfactors=2)

# use blue to red color gradient for the nugent score
# rbPal <- colorRampPalette(c('blue','red'))
# colpal <- rbPal(6)[as.numeric(cut( nugent, breaks = 6))]
# cuts <- c( "0", "2", "4", "6", "8", "10" )

svg("ilr.svg", width=10, height=10)
plot(ilr.projection[1,],ilr.projection[2,], xlab='PF1',ylab='PF2', main='Ordination by ILR Coordinates', pch=19 )#, col=colpal )
# legend("topright", cuts, col=rbPal(6), pch=19 )
#legend(-1,2.5,legend=c('Tongue','Poo'),fill=c('pink','brown'),cex=2)
dev.off()
