#!/usr/bin/Rscript

# library(compositions)
# library(ape)
# library(phytools)
# library(phangorn)
# library(caper)
# library(parallel)
# library(magrittr)
# library(Biostrings)

library(phylofactor)
library(phytools)

####################################################################
#    Reading
####################################################################

load("pf.RData")

write.table(Taxonomy, file = "taxonomy.csv")

####################################################################
#    Factored Edges
####################################################################

for (factor in 1:nfactors){

	print("======================================================")

	print(paste("Factor:", factor))
	FactorSummary <- pf.summary(PF,Taxonomy,factor=factor)

	# print the taxo paths of the groups split by this factor
	print( FactorSummary$TaxaSplit %>% lapply(.,FUN=function(x) unique(x$TaxaIDs)) )

	# factored edges
	factored.edge <- getFactoredEdges(PF$basis[,factor],Tree)
    #factored.edges <- getFactoredEdgesPAR(ncores=3,PF=PF) #Parallel; gets all factored edge

	Group1.otus <- FactorSummary$group1$IDs$otuIDs %>% as.list %>% sapply(.,toString)
	Group2.otus <- FactorSummary$group2$IDs$otuIDs %>% as.list %>% sapply(.,toString)
	Group1.edges <- extractEdges(Tree,taxa=Group1.otus,type=3)
	Group2.edges <- extractEdges(Tree,taxa=Group2.otus,type=3)

	# TidySummary <- pf.tidy(FactorSummary)

    print("Group1.otus:")
	print( Group1.otus )
	print("")
	print("Group2.otus:")
	print( Group2.otus )
    print("")

    write.table( Group1.otus, file = paste("pf_group1_", factor, ".csv", sep=""), col.names = F, row.names = F)

    # print("Group1 tax:")
    # print( Taxonomy[ Group1.otus, ] )
    # print("")
    # print("Group2 tax:")
    # print( Taxonomy[ Group2.otus, ] )
    # print("")

	edge.colors <- rep('black',Nedge(Tree))
	edge.colors[Group1.edges] <- 'green'
	edge.colors[Group2.edges] <- 'blue'
	edge.colors[factored.edge] <- 'red'

	### Let's also exaggerate the length of our factored edge:
	edge.lengths <- Tree$edge.length
	edge.lengths[factored.edge] <- 0.6

	svg(paste("tree_", factor, ".svg", sep=""), width=10, height=10)
	tr <- heattree
	tr$edge.length <- edge.lengths
	par(mfrow=c(1,1))
	plot.phylo(tr,type='phylogram',edge.color = edge.colors,show.tip.label = T,edge.width = 1,main=paste('Factor', factor), align.tip.label=T, cex=0.3)

	legend(-0.16,0.3,legend=c('Group 1','factored edge','Group 2'),fill=c('blue','red','green'))
	dev.off()

	print("")
	print("")
	# cat("\n\n")
}

####################################################################
#    ILR Ordination
####################################################################

#pf.ILRprojection(PF)
ilr.projection <- pf.ILRprojection(PF,nfactors=2)

# use blue to red color gradient for the nugent score
# rbPal <- colorRampPalette(c('blue','red'))
# colpal <- rbPal(6)[as.numeric(cut( nugent, breaks = 6))]
# cuts <- c( "0", "2", "4", "6", "8", "10" )

svg("ilr.svg", width=10, height=10)
plot(ilr.projection[1,],ilr.projection[2,], xlab='PF1',ylab='PF2', main='Ordination by ILR Coordinates', pch=19 )#, col=colpal )
# legend("topright", cuts, col=rbPal(6), pch=19 )
#legend(-1,2.5,legend=c('Tongue','Poo'),fill=c('pink','brown'),cex=2)
dev.off()
