OTU tree build from the swarmed BV OTUs
