#!/bin/bash

BASEDIR="path/to"

MAFFT=`which mafft`

SEQS=${BASEDIR}/17_balances/01_bv_swarm/derep_all.OTU_table.spread_20.fasta
THREADS=2

echo "`date` starting align"
echo

mafft-linsi ${SEQS} > derep_all.OTU_table.spread_20.align.fasta

echo
echo "`date` finished"
