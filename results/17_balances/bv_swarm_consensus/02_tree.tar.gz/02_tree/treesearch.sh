#!/bin/bash

BASEDIR="path/to"
RAXMLNG=path/to/raxml-ng_v0.7.0_linux_x86_64/raxml-ng
MSA=${BASEDIR}/17_balances/05_bv_swarm_consensus/consensus.fasta
THREADS=4

echo "`date` starting tree search"
echo

${RAXMLNG} --msa ${MSA} --model GTR+G --force --threads ${THREADS} --tree rand{30}

echo
echo "`date` finished"
