#!/usr/bin/Rscript

library(phylofactor)
library(phytools)

####################################################################
#    Reading
####################################################################

basedir <- "path/to/17_balances/"
otutable <- read.csv( file=file.path(basedir, "06_bv_pf_consensus/consensus_otu_table.txt"), sep=",", head=TRUE, row.names = 1 )
tree <- read.tree(file = file.path(basedir, "05_bv_swarm_consensus/consensus.fasta.raxml.bestTree"))
meta <- read.csv( file=file.path(basedir, "06_bv_pf_consensus/meta_simple.csv"), sep="\t", head=TRUE, row.names = 1 )
tax <- read.csv( file=file.path(basedir, "06_bv_pf_consensus/otu_assignment.txt"), sep="\t", head=FALSE, row.names = 1 )
#treenames <- read.csv( file=file.path(basedir, "03_bv_labels/assign/otu_assignments_species_only.txt"), sep="\t", head=FALSE, row.names = 1 )

#summary(otutable)
#summary(meta)
#summary(tax)
#summary(tree)

####################################################################
#    Preparation
####################################################################

nfactors <- 10

# change taxomony to the format expected by phylofactor
colnames(tax)[1] <- "taxonomy"
tax$OTU_ID = row.names(tax)
tax <- tax[c("OTU_ID", "taxonomy")]
#str(tax)

# sort by nugent score, and change to the format expected by phylofactor
meta <- meta[order(meta$nugent),]
nugent <- as.numeric(unlist(meta$nugent))
#nugent <- lapply(nugent, as.numeric)
#summary(nugent)

#summary(meta$nugent)
#meta$nugent

# sort otu table columns by nugent score
otutable <- otutable[c(row.names(meta))]

# change order in otu table to match tree, and
# change otu table to the format expected by phylofactor
otutable <- otutable[tree$tip.label,]
otutable <- as.matrix(otutable)
#summary(otutable)
#str(otutable)

####################################################################
#    Phylo Factor
####################################################################

PF <- PhyloFactor( otutable, tree, X=nugent, nfactors=nfactors )

#names(PF)
#PF$factors

####################################################################
#    Heatmap
####################################################################

# sort treenames by tree tip labels, prefix them by uniq id.
# also, because of fucking stupid R issues, 
# we need to remove white spaces from the names...
#treenames <- treenames[tree$tip.label,]
#nicenames <- paste( seq.int(1, length(treenames)), treenames )
#nicenames <- gsub(" ", "_", nicenames)
#nicenames <- gsub("\\.", "", nicenames)
#summary(treenames)

# now replace all by the nice tree names
heatdata <- PF$Data
heattree <- tree
#row.names(heatdata) <- nicenames
#heattree$tip.label <- nicenames

clr <- function(Matrix) apply(Matrix,MARGIN=2,FUN=function(x) log(x)-mean(log(x)))
par(mfrow=c(1,1))

svg("heatmap.svg", width=35, height=20 )
phylo.heatmap( heattree, clr(heatdata), fsize=c(0.5, 0.5, 2.0) )
dev.off()

####################################################################
#    Factored Edges
####################################################################

for (factor in 1:nfactors){

	print(paste("Factor:", factor))
	smry <- pf.summary(PF,tax,factor=factor)
	
	# print the taxo paths of the groups split by this factor
	print( smry$TaxaSplit %>% lapply(.,FUN=function(x) unique(x$TaxaIDs)) )

	# factored edges
	factored.edge <- getFactoredEdges(PF$basis[,factor],tree) 
    #factored.edges <- getFactoredEdgesPAR(ncores=3,PF=PF) #Parallel; gets all factored edge

	Group1.otus <- smry$group1$IDs$otuIDs %>% as.list %>% sapply(.,toString)
	Group2.otus <- smry$group2$IDs$otuIDs %>% as.list %>% sapply(.,toString)
	Group1.edges <- extractEdges(tree,taxa=Group1.otus,type=3)
	Group2.edges <- extractEdges(tree,taxa=Group2.otus,type=3)
	
	print("Group1.otus:")
	print( Group1.otus)
	#print(Group2.otus)

	edge.colors <- rep('black',Nedge(tree))
	edge.colors[Group1.edges] <- 'green'
	edge.colors[Group2.edges] <- 'blue'
	edge.colors[factored.edge] <- 'red'

	### Let's also exaggerate the length of our factored edge:
	edge.lengths <- tree$edge.length
	edge.lengths[factored.edge] <- 0.6

	svg(paste("tree_", factor, ".svg", sep=""), width=10, height=10)
	tr <- heattree
	tr$edge.length <- edge.lengths
	par(mfrow=c(1,1))
	plot.phylo(tr,type='phylogram',edge.color = edge.colors,show.tip.label = T,edge.width = 1,main=paste('Factor', factor), align.tip.label=T, cex=0.3)

	legend(-0.16,0.3,legend=c('Group 1','factored edge','Group 2'),fill=c('blue','red','green'))
	dev.off()
	
	cat("\n\n")
}

####################################################################
#    ILR Ordination
####################################################################

#pf.ILRprojection(PF)
ilr.projection <- pf.ILRprojection(PF,nfactors=2)

# use blue to red color gradient for the nugent score
rbPal <- colorRampPalette(c('blue','red'))
colpal <- rbPal(6)[as.numeric(cut( nugent, breaks = 6))]
cuts <- c( "0", "2", "4", "6", "8", "10" )

svg("ilr.svg", width=10, height=10)
plot(ilr.projection[1,],ilr.projection[2,], xlab='PF1',ylab='PF2', main='Ordination by ILR Coordinates', pch=19, col=colpal )
legend("topright", cuts, col=rbPal(6), pch=19 )
#legend(-1,2.5,legend=c('Tongue','Poo'),fill=c('pink','brown'),cex=2)
dev.off()


