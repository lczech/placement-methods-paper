/*
    Genesis - A toolkit for working with phylogenetic data.
    Copyright (C) 2014-2018 Lucas Czech and HITS gGmbH

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Contact:
    Lucas Czech <lucas.czech@h-its.org>
    Exelixis Lab, Heidelberg Institute for Theoretical Studies
    Schloss-Wolfsbrunnenweg 35, D-69118 Heidelberg, Germany
*/

#include "genesis/genesis.hpp"

#include <algorithm>
#include <cassert>
#include <fstream>
#include <limits>
#include <random>
#include <string>
#include <unordered_map>

using namespace genesis;
using namespace genesis::sequence;
using namespace genesis::utils;

int main( int, char** )
{
    // -------------------------------------------------------------------------
    //     Startup and command line args
    // -------------------------------------------------------------------------

    // Activate logging.
    utils::Logging::log_to_stdout();
    utils::Logging::details.time = true;
    LOG_BOLD << utils::Options::get().info();
    LOG_BOLD;

    LOG_INFO << "Started";

    // In out dirs.
    std::string const base_dir = "path/to/17_balances/";
    std::string const table_file = base_dir + "01_bv_swarm/derep_all.OTU.table.full";
    std::string const taxon_file = base_dir + "03_bv_labels/assign_all/otu_assignments.txt";
    std::string const out_file = base_dir + "06_bv_pf_consensus/consensus_otu_table.txt";

    // read tables
    auto csv_reader = CsvReader();
    csv_reader.separator_chars( "\t" );
    auto const table = csv_reader.read( from_file( table_file ));
    auto const assign = csv_reader.read( from_file( taxon_file ));

    // Turn assignments into lookup
    std::unordered_map<std::string, std::string> assign_lkp;
    for( auto const& line : assign ) {
        assert( line.size() == 2 );

        // clean label
        auto const p = line[1].find_last_of(";");
        auto const l = sanitize_label( line[1].substr( p+1 ));

        assert( assign_lkp.count(line[0]) == 0 );
        assign_lkp[line[0]] = l;
    }

    std::unordered_map<std::string, std::vector<size_t>> counts;
    for( size_t i = 1; i < table.size(); ++i ) {
        auto const& line = table[i];
        assert( line.size() == 228 );

        // get the taxon assignment of this otu
        auto const& otu = line[3];
        assert( assign_lkp.count(otu) > 0 );
        auto const& tax = assign_lkp[otu];

        // make an empty vec for all samples in the bv data
        if( counts.count(tax) == 0 ) {
            counts[tax] = std::vector<size_t>( 220, 0 );
        }

        // add up!
        for( size_t i = 0; i < 220; ++i ) {
            auto const c = std::stoi( line[i+8] );
            counts[tax][i] += c;
        }
    }

    // write header.
    std::ofstream otu_of;
    file_output_stream( out_file, otu_of );
    otu_of << "OTU";
    assert( table[0].size() == 228 );
    for( size_t i = 8; i < 228; ++i ) {
        otu_of << "," << table[0][i];
    }
    otu_of << "\n";

    // write table.
    for( auto const& entry : counts ) {
        otu_of << entry.first;
        size_t sum = 0;
        for( auto const& n : entry.second ) {
            otu_of << "," << n;
            sum += n;
        }
        otu_of << "\n";
        LOG_DBG << entry.first << ": " << sum;
    }

    LOG_INFO << "Finished";
    return 0;
}
