#!/bin/bash

rm -f tree.svg epa_info.log epa_result.jplace

epa="path/to/17_balances/03_bv_labels/place_all/epa-ng-master/bin/epa-ng"

# use the original ref, but we need to convert to fasta, because epa-ng... 
# so, we copied the file to here, and converted it.
#ref=path/to/03_bv/00_data/Ref.fasta
ref=path/to/17_balances/03_bv_labels/place/Ref.fasta.reduced
ref2=path/to/17_balances/03_bv_labels/place/Ref.fasta.reduced.fasta

all=path/to/17_balances/03_bv_labels/place_all/papara_alignment.bv_otus
tree=path/to/03_bv/01_treesearch/best_tree.newick

${epa} --split $ref $all

qry=path/to/17_balances/03_bv_labels/place_all/query.fasta

# copied from path/to/03_bv/01_treesearch/seeds
# this is the info file of the best tree of the bv ref data
#info=path/to/17_balances/03_bv_labels/place_all/RAxML_info.s23052

# nope, doesn't work, because old raxml does not use the same format for the info file
# when inferring the tree compared to using -e, so needed to run again, see model.sh
# this is thus the new info file, from which epa can take the model params
info=path/to/17_balances/03_bv_labels/place/RAxML_info.tree_model

${epa} --ref-msa $ref2 --tree $tree --query $qry --model $info

path/to/github/gappa/bin/gappa analyze visualize-color --jplace-path path/to/17_balances/03_bv_labels/place_all/epa_result.jplace --write-svg-tree
