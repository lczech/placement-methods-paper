#!/bin/bash

papara="path/to/papara_nt/papara"
NUM_TASKS=4

TREE=path/to/03_bv/01_treesearch/best_tree.newick
ALI=path/to/03_bv/00_data/Ref.phylip
QUERIES=path/to/17_balances/01_bv_swarm/otu_representatives.fasta

${papara} -t ${TREE} -s ${ALI} -q ${QUERIES} -j ${NUM_TASKS} -r -n bv_otus
