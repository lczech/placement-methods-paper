Using gappa assign to bring everything together: 

 - the `taxon_file.txt` from the parent dir is used to get tax labels for the tips of the bv ref tree
 - the `place/epa_result.jplace` file lists the placement of the OTUS on the ref tree
 - gappa assign then produces `per_pquery_assign` labels for each OTU, ...
 - ... which we then manually turned into `otu_assignments.txt` for the final taxonomic assignment of the OTUs
