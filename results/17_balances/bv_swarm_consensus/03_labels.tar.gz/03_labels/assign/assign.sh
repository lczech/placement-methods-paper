#!/bin/bash

gappa=path/to/gappa/bin/gappa

jplace=path/to/17_balances/03_bv_labels/place/epa_result.jplace
tax=path/to/17_balances/03_bv_labels/taxon_file.txt
outgr=path/to/17_balances/03_bv_labels/assign/outgroup.txt

$gappa analyze assign --jplace-path $jplace --taxon-file $tax --root-outgroup $outgr
