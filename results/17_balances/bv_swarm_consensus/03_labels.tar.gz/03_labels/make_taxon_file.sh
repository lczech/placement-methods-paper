#!/bin/bash

tax=path/to/17_balances/03_bv_labels/taxon_suggestions_final.txt
seq=path/to/17_balances/03_bv_labels/sequence_names.csv

rm -f taxon_file.txt

while IFS='' read -r line || [[ -n "$line" ]]; do

	echo "at ${line}"

	i=`echo -e "${line}" | cut -f 1`
	t=`echo -e "${line}" | cut -f 2`
	p=`grep "$t" ${tax} | cut -f 2`
	#echo "$i---$t---$p"
	
	echo -e "$i\t$p" >> taxon_file.txt

	# echo ${line} >> taxon_suggestions_map.txt
	# grep -ni "${line}" ${map} | head >> taxon_suggestions_map.txt
	# echo >> taxon_suggestions_map.txt
	#
	# echo ${line} >> taxon_suggestions_tax.txt
	# grep -ni ";${line};" ${tax} | head >> taxon_suggestions_tax.txt
	# echo >> taxon_suggestions_tax.txt

	# echo -ne "${line}\t" >> taxon_suggestions_good.txt
	# grep -ni "${line}" ${map} | head | cut -f 4-5 | sort -u | head -n 1 | sed 's/;\t/;/g' >> taxon_suggestions_good.txt
	# p=`echo ${expr} | cut -f 4`
	# s=`echo ${expr} | cut -f 5`
	# echo >> taxon_suggestions_good.txt

done < "${seq}"
