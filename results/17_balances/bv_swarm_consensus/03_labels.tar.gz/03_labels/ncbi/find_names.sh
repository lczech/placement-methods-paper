#!/bin/bash

ncbi=path/to/data/ncbi/ncbi.tax
rm -f taxon_suggestions.txt

while IFS='' read -r line || [[ -n "$line" ]]; do

	echo "at ${line}"
	
	echo ${line} >> taxon_suggestions.txt
	grep -ni ";${line};" ${ncbi} | head >> taxon_suggestions.txt
	echo >> taxon_suggestions.txt

done < "../taxon_names.txt"

