#!/bin/bash

cat sequence_names.csv | cut -f 2 | sort -u > taxon_names.txt
