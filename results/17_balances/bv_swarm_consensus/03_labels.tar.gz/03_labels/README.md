This directory contains the information for labelling the OTUs of the BV dataset with the original taxonomy:

 - First, we get the original taxon names of the BV ref tree:
    - `sequence_names.csv` contains the mapping of names used in the BV ref tree to their taxonomic name.
    - `taxon_names.sh` takes these and stores all uniq taxon names in `taxon_names.txt`.
 - Then, we use `find_names.sh` to look up these taxon names in a database. We mainly used silva, but added some from NCBI where silva was missing a taxonomic path.
 - The result is a mapping of taxon names to their paths, the silva-based (most important one) being `silva/taxon_suggestions_good.txt`
 - This was copied to `taxon_suggestions_final.txt`, where we then manually added missing paths (that were not in silva) using information from NCBI and other sources. Information on the missing ones is provided in `taxon_suggestions_missing_info.txt`.
 - Finally, `make_taxon_file.sh` takes the list of labels of the BV ref tree again (`sequence_names.csv`), and stores their taxonomic path (from the previous step) in `taxon_file.txt`.
 - The OTUs are placed on the bv ref tree in `place`.
 - This resulting placement file and the taxon file were then be used by `gappa assign` to label the placed OTUs, see `assign`
 
End result: taxonomic labels for the OTU sequences, stored in `assign/otu_assignments.txt`

Those can then be used for understanding the OTU tree and its results from phylo factorization.
For example, we need to look for the lactobacilii, which are important for this dataset.
So, for this, we need the OTU tree to have meaningfull tip labels (our taxo paths) instead of hash names.

Lastly, `tree` contains the tree from `02_bv_tree`, but with the tips renamed using the taxonomic labels (just the species names, for brevity)
