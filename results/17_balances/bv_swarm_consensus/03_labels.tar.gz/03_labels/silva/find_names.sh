#!/bin/bash

map=path/to/data/silva/taxmap_slv_ssu_ref_nr_123.1.txt
tax=path/to/data/silva/tax_slv_ssu_123.1.txt

# rm -f taxon_suggestions_map.txt
# rm -f taxon_suggestions_tax.txt
rm -f taxon_suggestions_good.txt
rm -f taxon_suggestions_missing.txt

while IFS='' read -r line || [[ -n "$line" ]]; do

	echo "at ${line}"

	# echo ${line} >> taxon_suggestions_map.txt
	# grep -ni "${line}" ${map} | head >> taxon_suggestions_map.txt
	# echo >> taxon_suggestions_map.txt
	#
	# echo ${line} >> taxon_suggestions_tax.txt
	# grep -ni ";${line};" ${tax} | head >> taxon_suggestions_tax.txt
	# echo >> taxon_suggestions_tax.txt

	echo -ne "${line}\t" >> taxon_suggestions_good.txt
	path=`grep -ni "${line}" ${map} | head | cut -f 4-5 | sort -u | head -n 1 | sed 's/;\t/;/g'`
	if [[ ${path} ]]; then
		echo $path >> taxon_suggestions_good.txt
	else
		echo ${line} >> taxon_suggestions_missing.txt
		echo >> taxon_suggestions_good.txt
	fi
	# p=`echo ${expr} | cut -f 4`
	# s=`echo ${expr} | cut -f 5`
	# echo >> taxon_suggestions_good.txt

done < "../taxon_names.txt"
