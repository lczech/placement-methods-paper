#!/bin/bash

raxml=/usr/bin/raxml

ref=path/to/03_bv/00_data/Ref.phylip
tree=path/to/03_bv/01_treesearch/best_tree.newick

$raxml -f e -s $ref -t $tree -n tree_model -m GTRGAMMAX

