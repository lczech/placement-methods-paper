This is the placement of the bv OTUs on the original bv tree. The goal is to use these placements to taxonomically assign (using gappa assign) the OTUs. The parent directory contains more information on this, such as the tax labels used for the bv ref tree.

Steps:

 - `align.sh`: use papara to align otus to bv ref ali/tree
 - `model.sh`: re-run raxml to get model params to be used for epa-ng
 - `place.sh`: run the placement, and make a nice vis
