#!/bin/bash

BASEDIR="path/to"

VSEARCH=`which vsearch`
#${BASEDIR}/software/vsearch-2.9.1-linux-x86_64/bin/vsearch
SWARM=path/to/swarm/bin/swarm
THREADS=4

# remove N chars!
FASTA_DIR=${BASEDIR}/17_balances/bv_swarm/PloSONE_communities_specimens
mkdir PloSONE_communities_specimens_N
cd ${FASTA_DIR}
for file in `ls *.fasta`; do

   cat ${file} | sed "s/N//g" > ../PloSONE_communities_specimens_N/${file}
done
cd -
FASTA_DIR=${BASEDIR}/17_balances/bv_swarm/PloSONE_communities_specimens_N/


# target dirs
mkdir derep

# get file names of all input files with no dir prefix
cd ${FASTA_DIR}
INPUT_FASTAS=`ls *.fasta`
cd -

# derep per file
echo "`date` per file dereplication"

for file in ${INPUT_FASTAS}; do
   echo "    at $file"

   "${VSEARCH}" \
       --derep_fulllength "${FASTA_DIR}/${file}" \
       --sizeout \
       --fasta_width 0 \
       --relabel_sha1 \
       --output "derep/${file}" 2>> derep.log
done

# Pool sequences
echo "`date` concat all"
ALL_FASTA="concat_all.fasta"
cat derep/*.fasta > ${ALL_FASTA}

# Dereplicate (vsearch)
echo "`date` derep all"
FINAL_FASTA="derep_all.fasta"
"${VSEARCH}" --derep_fulllength "${ALL_FASTA}" \
             --sizein \
             --sizeout \
             --fasta_width 0 \
             --output "${FINAL_FASTA}" > derep_all.log

echo
echo "`date` finished"
