#!/bin/bash

FASTA="derep_all.fasta"
SCRIPT="OTU_contingency_table.py"
STATS="${FASTA/.fasta/_1f.stats}"
SWARMS="${FASTA/.fasta/_1f.swarms}"
REPRESENTATIVES="otu_representatives.fasta"

# Unused by our modified script:
# UCHIME="${FASTA/.fasta/_1f_representatives.uchime}"
# ASSIGNMENTS="${FASTA/.fasta/_1f_representatives.results}"
# QUALITY="coolproject.assembled.qual"
UCHIME="x"
ASSIGNMENTS="y"
QUALITY="z"

OTU_TABLE="${FASTA/.fasta/.OTU.table.full}"

python2 \
    "${SCRIPT}" \
    "${REPRESENTATIVES}" \
    "${STATS}" \
    "${SWARMS}" \
    "${UCHIME}" \
    "${QUALITY}" \
    "${ASSIGNMENTS}" \
    derep/*.fasta > "${OTU_TABLE}"
