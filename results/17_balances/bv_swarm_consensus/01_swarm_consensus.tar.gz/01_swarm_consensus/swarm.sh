#!/bin/bash

BASEDIR="path/to"

VSEARCH=`which vsearch`
#${BASEDIR}/software/vsearch/bin/vsearch
SWARM=path/to/swarm/bin/swarm

INPUT_FASTA=${BASEDIR}/17_balances/bv_swarm/derep_all.fasta
REPRESENTATIVES="otu_representatives.fasta"

THREADS=4

echo "`date` starting swarm: clustering"
echo

"${SWARM}" \
    -d 1 -f -z -t ${THREADS} \
    -i ${INPUT_FASTA/.fasta/_1f.struct} \
    -s ${INPUT_FASTA/.fasta/_1f.stats} \
    -w ${REPRESENTATIVES} \
    -o ${INPUT_FASTA/.fasta/_1f.swarms} < ${INPUT_FASTA}

#echo
#echo "`date` starting vsearch: sort representatives"
# Sort representatives
#"${VSEARCH}" --fasta_width 0 \
#             --sortbysize ${REPRESENTATIVES} \
#             --output ${REPRESENTATIVES}.sorted

echo
echo "`date` finished"
