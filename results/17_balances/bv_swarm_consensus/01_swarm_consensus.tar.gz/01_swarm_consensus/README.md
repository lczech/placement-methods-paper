Preparation of the BV dataset for phylofactor: 
swarm the data, make an OTU table, and a list of sequences of each OTU

1. `derep.sh`: take all input files `PloSONE_communities_specimens`, remove N chars (not allowed by swarm), dereplicate into `derep`
2. `swarm.sh`: swarm them, build stats etc
3. `otu_table.sh`: make an out table, using our custom python script adapted from https://github.com/frederic-mahe/swarm/wiki/Fred's-metabarcoding-pipeline
   the script prints a fasta file and an otu table in a nice format, for just the otus with a spread of at least 20
   
the important result files are `derep_all.OTU_table.spread_20.csv` and `derep_all.OTU_table.spread_20.fasta`
