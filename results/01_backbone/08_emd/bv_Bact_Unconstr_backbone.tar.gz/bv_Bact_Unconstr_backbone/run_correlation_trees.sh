#!/bin/bash

BASE_DIR="/home/lucas/Projects/bacardi/01_backbone/08_emd/bv_Bact_Unconstr_backbone"
DATA_DIR="/home/lucas/Projects/data"

TREE="${BASE_DIR}/avg_tree.newick"
EDGE_W="${BASE_DIR}/edge_weights.mat"
IMBALANCE="${BASE_DIR}/imbalance.mat"
BPLACE_ORDER="${BASE_DIR}/bplace_order.list"
META="${DATA_DIR}/bv/meta/meta_simple.csv"
OUT="${BASE_DIR}/test2/"

PROG="/home/lucas/Dropbox/HITS/genesis/bin/apps/correlation_trees"

mkdir -p ${OUT}

${PROG} ${TREE} ${EDGE_W} ${IMBALANCE} ${BPLACE_ORDER} ${META} ${OUT}
